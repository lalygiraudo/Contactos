# views/__init__.py
# Este archivo hace que la carpeta views sea un paquete Python

from .app_gui import App

__all__ = ['App']